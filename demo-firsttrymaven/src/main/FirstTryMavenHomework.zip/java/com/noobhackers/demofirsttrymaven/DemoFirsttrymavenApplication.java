package com.noobhackers.demofirsttrymaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoFirsttrymavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoFirsttrymavenApplication.class, args);
	}

}
